
### Journey Log
---
**YEAR:** 
**SEASON:**
**JOURNEY FROM:**
**DESTINATION:**
**DAYS OF TRAVEL:**

#### The Company

| Name                              | Journey Role | Travel Fatigue |
| --------------------------------- | ------------ | -------------- |
|   | Hunter       | 0               |
|    | Scout        |    0            |
|  | Look-out     |       0         |
|   | Guide        |      0          |

#### Ponies and horses

| Name | Vigour |
| ---- | ------ |
|      |        |


#### Journey Path



#### Event 1

**Target:**
**Event:**
**Result:**

#### Event 2

**Target:**
**Event:**
**Result:**

#### Event 3

**Target:**
**Event:**
**Result:**

#### Event 4

**Target:**
**Event:**
**Result:**

#### Journal

