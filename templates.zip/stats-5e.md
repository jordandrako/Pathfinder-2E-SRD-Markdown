```statblock
name: 
size: 
type: 
subtype: 
alignment: 
ac: 
hp: 
hit_dice: 
speed: 
stats: []
saves:
  - 
skillsaves:
  - 
damage_vulnerabilities: 
damage_resistances: 
damage_immunities: 
condition_immunities: 
senses: 
languages: 
cr: 
traits:
  - []
spells:
  - description
  - spell level: spell-list
actions:
  - []
legendary_actions:
  - []
reactions:
  - []
```