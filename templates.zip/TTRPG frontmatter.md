---
type: 
faction: 
location: 
world: <% tp.user.getThisWorld(tp) %>
campaign: <% tp.file.folder(false) %>
date: <% tp.date.now("YYYY-MM-DD") %>
description: ""
race: 
gender: 
class: 
---
# [[<% tp.file.title %>]]

