```statblock
layout: Generic OSR Layout
name: 
art: 
hd: 
hp: 
ac: 
morale: 
traits:
  - []
actions:
  - []
```