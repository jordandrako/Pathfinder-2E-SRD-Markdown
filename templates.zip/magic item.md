---
name: <% tp.file.title %>
type: 
attunement: 
rarity: 
tags: 
requires: 
source: ""
---
# [[<% tp.file.title %>]]

