---
name: <% tp.file.title %>
size: 
type: 
environment: 
hp: 
ac: 
initiative: 
alignment: 
legendary: 
lair: 
unique: 
cr: 
tags: 
source: ""
---
# <% tp.file.title %>

