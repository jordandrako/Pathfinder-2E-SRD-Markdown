
hp: 
ac: 
modifier: 
level: 