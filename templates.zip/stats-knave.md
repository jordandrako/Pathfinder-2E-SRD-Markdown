```statblock
layout: Knave 2e
name: Name
hp: 1
armor: 10
level: 1
xp: 0
str: 0
dex: 0
con: 0
int: 0
wis: 0
cha: 0
careers: Grave robber
traits:
  - ["Build, Gaunt"]
actions:
  - ["Test, test item"]
```
