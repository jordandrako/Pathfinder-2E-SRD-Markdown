
```statblock
layout: Basic Fate Core Layout
image: 
name: Barathar
description: an awkward sunbear
aspects:
  - Smuggler Queen of the Sindral Reach
  - A Mostly Loyal Crew
```
