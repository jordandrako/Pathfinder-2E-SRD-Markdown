
```statblock
layout: Numenera PC
name: 
image: 
descriptor: 
type: 
focus: 
armor: 0
tier: 1
effort: 1
xp: 0 
might: 0
mightedge: 0
speed: 0
speededge: 0
speedcost: 0
intellect: 0
intellectedge: 0
abilities:
- [Ability, Description.]
cyphers:
- ["[[Cypher page]]", "Description."]
skills:
- [Skill, Description.]
equipment:
- [Equipment, Description]
attacks:
- [Attack, Description]
```

