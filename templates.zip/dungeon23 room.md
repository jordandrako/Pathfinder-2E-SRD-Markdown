%%
date:: [[<% tp.date.now("YYYY-MM-DD") %>]]
%%
# [[<% tp.file.title %>]]

Parent:: [[Dungeon23 Megadungeon]]

- 
  
## Image

